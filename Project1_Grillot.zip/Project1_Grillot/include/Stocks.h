#ifndef STOCKS_H
#define STOCKS_H
//Date, Open, High, Low, Close, Volume, Adjusted Close
struct  ticker{
    std::string date;
    double open;
    double high;
    double low;
    double close;
    int volume;
    double adjustedclose;
};

class Stocks
{
    public:
        Stocks();
        Stocks(std::string, double, double, double, double, int, double ;
        ~Stocks();
    protected:
    private:
};

#endif // STOCKS_H
