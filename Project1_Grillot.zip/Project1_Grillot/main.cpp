#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <stdio.h>
#include <stdlib.h>
#include "Stocks.h"


using namespace std;



int main(){
    ifstream data;
    int counter=0;
    /*while(counter==0){
    cout<<"Portfolio Options: Netflix, Chipotle, Amazon (Choose one) "<<endl;
    string ticker;
    cin>>ticker;

    if(ticker=="Netflix"){
    data.open("Netflix.csv");
    counter++;
    }
    if(ticker=="Chipotle"){
    data.open("Chiptole.csv");
    counter++;
    }
    if(ticker=="Amazon"){
    data.open("Amazon.csv");
    counter++;
    }
    }*/
    data.open("Netflix.csv");

    string word;
    Stocks annualdata;//class
    //Date, Open, High, Low, Close, Volume, Adjusted Close
    ticker info;//struct
    int lineindex=0;
    while(getline(data, word, '\n')){


            stringstream ss;
            int wordindex=0;
            if(lineindex>0){
            ss<<word;



            while(getline(ss,word,',')){
                if(wordindex==0){//10 lines of data total
                    info.date=word;
                }
                 if(wordindex==1){//10 lines of data total
                    string temp;
                    temp=word;
                    double x;
                    x=atof(temp.c_str());
                    info.open=x;


                }
                 if(wordindex==2){//10 lines of data total
                    string temp;
                    temp=word;
                    double x;
                    x=atof(temp.c_str());
                    info.high=x;

                }
                 if(wordindex==3){//10 lines of data total
                    string temp;
                    temp=word;
                    double x;
                    x=atof(temp.c_str());
                    info.low=x;

                }
                 if(wordindex==4){//10 lines of data total
                    string temp;
                    temp=word;
                    double x;
                    x=atof(temp.c_str());
                    info.close=x;

                }
                 if(wordindex==5){//10 lines of data total
                    string temp;
                    temp=word;
                    int x;
                    x=atoi(temp.c_str());
                    info.volume=x;

                }
                 if(wordindex==6){//10 lines of data total
                    string temp;
                    temp=word;
                    double x;
                    x=atof(temp.c_str());
                    info.adjustedclose=x;

                }

            wordindex++;
            }
            }
        annualdata.addDay(info);
        lineindex++;
    }
    annualdata.maxprofit();
    annualdata.oneyear();
    annualdata.sixmonths();
    annualdata.maxloss();

    return 0;
}
