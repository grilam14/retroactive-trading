#ifndef STOCKS_H
#define STOCKS_H
#include <string>
//Date, Open, High, Low, Close, Volume, Adjusted Close
struct ticker{
    std::string date;
    double open;
    double high;
    double low;
    double close;
    int volume;
    double adjustedclose;
};

class Stocks
{
    public:
        Stocks();
        Stocks(std::string, double, double, double, double, int, double);
        void addDay(ticker);
        void maxprofit();
        void oneyear();
        void sixmonths();
        void maxloss();



    protected:
    private:
        int index=253;
        ticker annual[254];
        double money=1000;
        int shares;

};

#endif // STOCKS_H
