#include "Stocks.h"
#include <iostream>
using namespace std;

Stocks::Stocks(string d, double o, double, h, double l, double c, int v, double ac)
{
  string date=d;
  double open=o;
  double high=h;
  double low=l;
  int volume=v;
  double adjustedclose=ac;//Date, Open, High, Low, Close, Volume, Adjusted Close
}

Stocks::Stocks()
{
    //dtor
}
void Stocks::addDay(ticker){
    cout<<"if"<<endl;


}

